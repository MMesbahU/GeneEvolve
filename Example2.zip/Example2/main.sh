
wget https://github.com/rtahmasbi/GeneEvolve/raw/master/Example2.zip
unzip Example2.zip
cd Example2




GeneEvolve \
--file_gen_info par.geninfo.txt \
--file_ref_vcf par.vcf_sample_address.txt \
--file_recom_map Recom.Map.b37.50KbDiff \
--file_cv_info par.cv.info \
--file_cvs par.cv_hap_files.txt \
--out_vcf \
--prefix out1


