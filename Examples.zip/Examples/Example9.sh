../bin/GeneEvolve \
--file_gen_info ex9.popinfo.txt \
--file_hap_name par.pop1.hap_sample_address.txt \
--file_recom_map Recom.Map.b37.50KbDiff \
--file_cv_info cv.info \
--file_cvs par.pop1.cv_hap_files.txt \
--avoid_inbreeding \
--va 1 \
--vd 0 \
--ve 1 \
--no_output \
--seed 12345 \
--prefix out.ex9

