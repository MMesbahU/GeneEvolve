../bin/GeneEvolve \
--file_gen_info ex7.popinfo.txt \
--file_hap_name par.pop1.hap_sample_address.txt \
--file_recom_map Recom.Map.b37.50KbDiff \
--file_cv_info cv.info \
--file_cvs par.pop1.cv_hap_files.txt \
--avoid_inbreeding \
--no_output \
--seed 12345 \
--prefix out.ex7

